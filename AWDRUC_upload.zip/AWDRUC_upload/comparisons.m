clear

load('sol_RO.mat','uo_exa_RO','uu_exa_RO','ud_exa_RO','xu_exa_RO','xl_exa_RO');

for is = 1 : 50

    fname = sprintf('sol_AWDR_%d.mat',is);
    load(fname,'uo_aff_DRO_limited','uu_aff_DRO_limited','ud_aff_DRO_limited',...
        'xu_aff_DRO_limited','xl_aff_DRO_limited','J_oos','T','w_forecast','cap',...
        'Fg','Fp','Fl_shed','I_T','Fmax','Fmin','w_forecast_vec','Fl','d','ng','np','nl_shed',...
        'Cu','Csu','Csd','d_sum','w_forecast_sum','Cg_ext','d_shed_limit');

    fname = sprintf('sol_SP_%d.mat',is);
    load(fname,'uo_exa_SP','uu_exa_SP','ud_exa_SP','xu_exa_SP','xl_exa_SP');

    wind_err_oos_raw = cell(np,1);
    for ip = 1 : np
        wind_err_oos_raw{ip,1} = zeros(J_oos*T,1);
        for t = 1 : T
            for j = 1 : J_oos
                if w_forecast(t,ip) == 0
                    wind_err_oos_raw{ip,1}((j-1)*T + t) = 0;
                else
                    wind_err_oos_raw{ip,1}((j-1)*T + t) = normrnd(0,w_forecast(t,ip) * 0.2)/w_forecast(t,ip);
                end
            end
        end
    end

    rel_SP = 0;
    Ain_oos = [
        kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T);
        -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T)
        ];
    Aeq_oos = kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T));

    w_err_oos_data = cell(J_oos,1);
    w_err_oos_data_vec = cell(J_oos,1);

    for j = 1 : J_oos
        w_err_oos_data{j} = zeros(T,np);
        w_err_oos_data_vec{j} = zeros(np*T,1);
        for t = 1 : T
            for ip = 1 : np
                dum = w_forecast(t,ip) + cap(ip) * wind_err_oos_raw{ip}( (j-1)*T + t );
                if dum > cap(ip)
                    w_err_oos_data{j}(t,ip) = cap(ip) - w_forecast(t,ip);
                else 
                    if dum < 0
                        w_err_oos_data{j}(t,ip) = - w_forecast(t,ip);
                    else
                        w_err_oos_data{j}(t,ip) = cap(ip) * wind_err_oos_raw{ip}( (j-1)*T + t );
                    end
                end
                w_err_oos_data_vec{j}((ip-1)*T + t) = w_err_oos_data{j}(t,ip);
            end
        end

        bin_oos = [
            kron(Fmax,ones(T,1)) - kron(Fp,I_T)*(w_forecast_vec + w_err_oos_data_vec{j}) + kron(Fl,I_T)*d;
            -kron(Fmin,ones(T,1)) + kron(Fp,I_T)*(w_forecast_vec + w_err_oos_data_vec{j}) - kron(Fl,I_T)*d;
            ];
        beq_oos = d_sum - w_forecast_sum - sum(w_err_oos_data{j},2);

        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_aff_DRO_limited; zeros(np*T+nl_shed*T,1)],[xu_aff_DRO_limited; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_aff_DRO_limited(j,1) = kron(Cu,ones(T,1))'*uo_aff_DRO_limited + kron(Csu,ones(T,1))'*uu_aff_DRO_limited + kron(Csd,ones(T,1))'*ud_aff_DRO_limited + dum;

        [~,dum,exitflag_SP] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_exa_SP; zeros(np*T+nl_shed*T,1)],[xu_exa_SP; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        if  exitflag_SP > 0
            fval_oos_exa_SP(j,1) = kron(Cu,ones(T,1))'*uo_exa_SP + kron(Csu,ones(T,1))'*uu_exa_SP + kron(Csd,ones(T,1))'*ud_exa_SP + dum;
            rel_SP = rel_SP + 1/J_oos;
        end

        [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_exa_RO; zeros(np*T+nl_shed*T,1)],[xu_exa_RO; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        fval_oos_exa_RO(j,1) = kron(Cu,ones(T,1))'*uo_exa_RO + kron(Csu,ones(T,1))'*uu_exa_RO + kron(Csd,ones(T,1))'*ud_exa_RO + dum;

        %[~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_exa_DRO; zeros(np*T+nl_shed*T,1)],[xu_exa_DRO; w_forecast_vec + w_err_oos_data_vec{j}; d_shed_limit]);
        %fval_oos_exa_DRO(j,1) = kron(Cu,ones(T,1))'*uo_exa_DRO + kron(Csu,ones(T,1))'*uu_exa_DRO + kron(Csd,ones(T,1))'*ud_exa_DRO + dum;

    end

    fname = sprintf('comparisons_%d.mat', is);
    save(fname,'fval_oos_aff_DRO_limited','fval_oos_exa_SP','fval_oos_exa_RO','rel_SP')
    %save(fname,'fval_oos_aff_DRO_limited','fval_oos_exa_DRO')

end
