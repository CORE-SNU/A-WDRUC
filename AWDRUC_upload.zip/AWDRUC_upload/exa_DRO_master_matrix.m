C21 = [ 
    zeros(ng*T) eye(ng*T); 
    -eye(ng*T) zeros(ng*T)
    ];
C22 = [
    -eye(ng*T);
    eye(ng*T)
    ];
c2 = zeros(2*ng*T,1);

C61 = [ 
    -kron(Fg,I_T);
    kron(Fg,I_T)
    ];
C62 = [
    kron(Fp,I_T);
    -kron(Fp,I_T)
    ];
C63 = [
    -kron(Fl_shed,I_T);
    kron(Fl_shed,I_T)
    ];
c6 = [
    - kron(Fmin,ones(T,1)) - kron(Fl,I_T)*d
    kron(Fmax,ones(T,1)) + kron(Fl,I_T)*d;
    ];
C64 = [
    kron(Fp,I_T);
    - kron(Fp,I_T)
    ];

C81 = kron(ones(1,ng),I_T);
C82 = -kron(ones(1,np),I_T);
C83 = kron(ones(1,nl_shed),I_T);
c8 = kron(ones(1,nl),eye(T))*d;
C84 = -kron(ones(1,np),I_T);
