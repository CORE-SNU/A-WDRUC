n_feas = 2*np + 2*np*M + 2*np + 2*ng + np + nl_shed + 2*M + 2;

Ain_feas1 = [
    zeros(ng,2*np+2*np*M+2*np) -I_ng I_ng zeros(ng,np+nl_shed) -Fg' Fg' ones(ng,1) -ones(ng,1);
    zeros(np,2*np+2*np*M+2*np+2*ng) I_np zeros(np,nl_shed) Fp' -Fp' -ones(np,1) ones(np,1);
    zeros(nl_shed,2*np+2*np*M+2*np+2*ng+np) I_nl_shed -Fl_shed' Fl_shed' ones(nl_shed,1) -ones(nl_shed,1);
    zeros(1,2*np+2*np*M+2*np) -ones(1,2*ng+np+nl_shed+2*M+2)
    ];
Ain_feas1 = -Ain_feas1;
bin_feas1 = [
    zeros(ng,1);
    zeros(np,1);
    zeros(nl_shed,1);
    -1
    ];
bin_feas1 = -bin_feas1;

Ain_feas2 = [
    -G_feas*I_np I_np zeros(np,n_feas - 2*np);
    G_feas*I_np -I_np zeros(np,2*np*M + 2*np + 2*ng) eye(np) zeros(np, nl_shed + 2*M + 2);
    zeros(np) I_np zeros(np,2*np*M + 2*np + 2*ng) -eye(np) zeros(np,nl_shed + 2*M + 2)
    ];
bin_feas2 = [
    zeros(np,1);
    G_feas*ones(np,1);
    zeros(np,1)
    ];

Ain_feas3 = [
    -G_feas*kron(ones(M,1),eye(np)) zeros(np*M,np) eye(np*M) zeros(np*M,np*M + 2*np + 2*ng + np + nl_shed + 2*M + 2);
    G_feas*kron(ones(M,1),eye(np)) zeros(np*M,np) -eye(np*M) zeros(np*M,np*M+2*np+2*ng+np+nl_shed) kron(eye(M),ones(np,1)) zeros(np*M,M+2);
    zeros(np*M,2*np) eye(np*M) zeros(np*M,np*M+2*np+2*ng+np+nl_shed) -kron(eye(M),ones(np,1)) zeros(np*M,M+2)
    ];
bin_feas3 = [
    zeros(np*M,1);
    G_feas*ones(np*M,1);
    zeros(np*M,1)
    ];

Ain_feas4 = [
    -G_feas*kron(ones(M,1),eye(np)) zeros(np*M,np+np*M) eye(np*M) zeros(np*M,2*np + 2*ng + np + nl_shed + 2*M + 2);
    G_feas*kron(ones(M,1),eye(np)) zeros(np*M,np+np*M) -eye(np*M) zeros(np*M,2*np+2*ng+np+nl_shed+M) kron(eye(M),ones(np,1)) zeros(np*M,2);
    zeros(np*M,2*np+np*M) eye(np*M) zeros(np*M,2*np+2*ng+np+nl_shed+M) -kron(eye(M),ones(np,1)) zeros(np*M,2)    
    ];
bin_feas4 = [
    zeros(np*M,1);
    G_feas*ones(np*M,1);
    zeros(np*M,1)
    ];

Ain_feas5 = [
    -G_feas*eye(np) zeros(np,np+2*np*M) eye(np) zeros(np,np+2*ng+np+nl_shed+2*M+2);
    G_feas*eye(np) zeros(np,np+2*np*M) -eye(np) zeros(np,np+2*ng+np+nl_shed+2*M) ones(np,1) zeros(np,1);
    zeros(np,2*np+2*np*M) eye(np) zeros(np,np+2*ng+np+nl_shed+2*M) -ones(np,1) zeros(np,1)
    ];
bin_feas5 = [
    zeros(np,1);
    G_feas*ones(np,1);
    zeros(np,1)
    ];

Ain_feas6 = [
    -G_feas*eye(np) zeros(np,np+2*np*M+np) eye(np) zeros(np,2*ng+np+nl_shed+2*M+2);
    G_feas*eye(np) zeros(np,np+2*np*M+np) -eye(np) zeros(np,2*ng+np+nl_shed+2*M+1) ones(np,1);
    zeros(np,2*np+2*np*M+np) eye(np) zeros(np,2*ng+np+nl_shed+2*M+1) -ones(np,1)
    ];
bin_feas6 = [
    zeros(np,1);
    G_feas*ones(np,1);
    zeros(np,1)
    ];

Ain_feas = [ 
    Ain_feas1; Ain_feas2; Ain_feas3; Ain_feas4; 
    Ain_feas5; Ain_feas6 ];
bin_feas = [ 
    bin_feas1; bin_feas2; bin_feas3; bin_feas4; 
    bin_feas5; bin_feas6 ];
lb_feas = zeros(n_feas,1);
ub_feas = [ ones(2*np,1); inf*ones(n_feas - 2*np,1) ];
ctype_feas = [ repmat('B',1,2*np) repmat('C',1,n_feas - 2*np) ];
