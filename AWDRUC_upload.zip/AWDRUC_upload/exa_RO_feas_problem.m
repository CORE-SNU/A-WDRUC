imbalance = 0;
sigma = zeros(np*T,1);

for t = 1 : T
    
    f_feas = [
        zeros(np,1); 
        kron( I_np,I_T(t,:) ) * (w_err_u_vec - w_err_l_vec); 
        reshape( Fp',[],1 ) .* kron( ones(M,1),kron(I_np,I_T(t,:)) * (w_err_u_vec - w_err_l_vec) ); 
        - reshape( Fp',[],1 ) .* kron( ones(M,1),kron(I_np,I_T(t,:)) * (w_err_u_vec - w_err_l_vec) ); 
        - kron( I_np,I_T(t,:) ) * (w_err_u_vec - w_err_l_vec); 
        kron( I_np,I_T(t,:) ) * (w_err_u_vec - w_err_l_vec); 
        - kron( I_ng,I_T(t,:) ) * xl;
        kron( I_ng,I_T(t,:) ) * xu;
        kron( I_np,I_T(t,:) ) * ( w_forecast_vec+w_err_l_vec );
        kron( I_nl_shed,I_T(t,:) ) * d_shed_limit;
        - Fmin - Fl * kron( I_nl,I_T(t,:) ) * d + Fp * kron( I_np,I_T(t,:) ) * ( w_forecast_vec+w_err_l_vec );
        Fmax + Fl * kron( I_nl,I_T(t,:) ) * d - Fp * kron( I_np,I_T(t,:) ) * ( w_forecast_vec+w_err_l_vec );
        kron( ones(1,nl),I_T(t,:) ) * d - kron( ones(1,np),I_T(t,:) ) * ( w_forecast_vec+w_err_l_vec );
        - kron( ones(1,nl),I_T(t,:) ) * d + kron( ones(1,np),I_T(t,:) ) * ( w_forecast_vec+w_err_l_vec )
        ];

    [sol_feas,fval_feas] = cplexmilp(f_feas,Ain_feas,bin_feas,[],[],[],[],[],lb_feas,ub_feas,ctype_feas);
    
    sigma = sigma + kron(sol_feas(1:np),I_T(:,t));

    imbalance = imbalance - fval_feas;
end
