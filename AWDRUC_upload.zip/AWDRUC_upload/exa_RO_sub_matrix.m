n_sub = 2*np + 2*np*M + 2*np + 2*ng + np + nl_shed + 2*M + 2;

Ain_sub1 = [
    zeros(ng,2*np+2*np*M+2*np) -I_ng I_ng zeros(ng,np+nl_shed) -Fg' Fg' ones(ng,1) -ones(ng,1);
    zeros(np,2*np+2*np*M+2*np+2*ng) I_np zeros(np,nl_shed) Fp' -Fp' -ones(np,1) ones(np,1);
    zeros(nl_shed,2*np+2*np*M+2*np+2*ng+np) I_nl_shed -Fl_shed' Fl_shed' ones(nl_shed,1) -ones(nl_shed,1);
    ];
Ain_sub1 = -Ain_sub1;
bin_sub1 = zeros(ng+np+nl_shed,1);

Ain_sub2 = [
    -G*I_np I_np zeros(np,n_sub - 2*np);
    G*I_np -I_np zeros(np,2*np*M + 2*np + 2*ng) eye(np) zeros(np, nl_shed + 2*M + 2);
    zeros(np) I_np zeros(np,2*np*M + 2*np + 2*ng) -eye(np) zeros(np,nl_shed + 2*M + 2)
    ];
bin_sub2 = [
    zeros(np,1);
    G*ones(np,1);
    zeros(np,1)
    ];

Ain_sub3 = [
    -G*kron(ones(M,1),eye(np)) zeros(np*M,np) eye(np*M) zeros(np*M,np*M + 2*np + 2*ng + np + nl_shed + 2*M + 2);
    G*kron(ones(M,1),eye(np)) zeros(np*M,np) -eye(np*M) zeros(np*M,np*M + 2*np + 2*ng + np + nl_shed) kron(eye(M),ones(np,1)) zeros(np*M,M+2);
    zeros(np*M,2*np) eye(np*M) zeros(np*M,np*M + 2*np + 2*ng + np + nl_shed) -kron(eye(M),ones(np,1)) zeros(np*M,M+2)    
    ];
bin_sub3 = [
    zeros(np*M,1);
    G*ones(np*M,1);
    zeros(np*M,1)
    ];

Ain_sub4 = [
    -G*kron(ones(M,1),eye(np)) zeros(np*M,np+np*M) eye(np*M) zeros(np*M,2*np + 2*ng + np + nl_shed + 2*M + 2);
    G*kron(ones(M,1),eye(np)) zeros(np*M,np+np*M) -eye(np*M) zeros(np*M,2*np + 2*ng + np + nl_shed + M) kron(eye(M),ones(np,1)) zeros(np*M,2);
    zeros(np*M,2*np+np*M) eye(np*M) zeros(np*M,2*np+2*ng+np+nl_shed+M) -kron(eye(M),ones(np,1)) zeros(np*M,2)    
    ];
bin_sub4 = [
    zeros(np*M,1);
    G*ones(np*M,1);
    zeros(np*M,1)
    ];

Ain_sub5 = [
    -G*eye(np) zeros(np,np+2*np*M) eye(np) zeros(np,np+2*ng+np+nl_shed+2*M+2);
    G*eye(np) zeros(np,np+2*np*M) -eye(np) zeros(np,np+2*ng+np+nl_shed+2*M) ones(np,1) zeros(np,1);
    zeros(np,2*np+2*np*M) eye(np) zeros(np,np+2*ng+np+nl_shed+2*M) -ones(np,1) zeros(np,1)
    ];
bin_sub5 = [
    zeros(np,1);
    G*ones(np,1);
    zeros(np,1)
    ];

Ain_sub6 = [
    -G*eye(np) zeros(np,np+2*np*M+np) eye(np) zeros(np,2*ng+np+nl_shed+2*M+2);
    G*eye(np) zeros(np,np+2*np*M+np) -eye(np) zeros(np,2*ng+np+nl_shed+2*M+1) ones(np,1);
    zeros(np,2*np+2*np*M+np) eye(np) zeros(np,2*ng+np+nl_shed+2*M+1) -ones(np,1)
    ];
bin_sub6 = [
    zeros(np,1);
    G*ones(np,1);
    zeros(np,1)
    ];

Ain_sub = [ 
    Ain_sub1; Ain_sub2; Ain_sub3; Ain_sub4; 
    Ain_sub5; Ain_sub6 ];
bin_sub = [ 
    bin_sub1; bin_sub2; bin_sub3; bin_sub4; 
    bin_sub5; bin_sub6 ];
lb_sub = zeros(n_sub,1);
ub_sub = [ ones(2*np,1); inf*ones(n_sub - 2*np,1) ];
ctype_sub = [ repmat('B',1,2*np) repmat('C',1,n_sub - 2*np) ];
