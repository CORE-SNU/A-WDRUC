clear

for is = 1 : 50
    
    fname = sprintf('sol_AWDR_%d.mat', is);
    load(fname)
    
    tic

    Ain_wind_err_basic = [ eye(np); -eye(np) ];
    bin_wind_err_basic = cell(T,1);
    for t = 1 : T
        bin_wind_err_basic{t} = [ cap - w_forecast(t,:)'; w_forecast(t,:)' ];
    end

    common_matrix

    % Hold-out (in-sample)
    w_err_data_HO_in = cell(J_HO_in,1);
    w_err_data_vec_HO_in = cell(J_HO_in,1);
    for j = 1 : J_HO_in
        w_err_data_HO_in{j} = zeros(T,np);
        w_err_data_vec_HO_in{j} = zeros(np*T,1);
        for ip = 1 : np
            for t = 1 : T
                w_err_data_HO_in{j}(t,ip) = w_err_data{j}(t,ip);
                w_err_data_vec_HO_in{j}((ip-1)*T + t) = w_err_data_vec{j}((ip-1)*T + t);
            end
        end
    end

    % Hold-out (out-of-sample)
    w_err_data_HO_oos = cell(J_HO_oos,1);
    w_err_data_vec_HO_oos = cell(J_HO_oos,1);
    for j = 1 : J_HO_oos
        w_err_data_HO_oos{j} = zeros(T,np);
        w_err_data_vec_HO_oos{j} = zeros(np*T,1);
        for ip = 1 : np
            for t = 1 : T
                w_err_data_HO_oos{j}(t,ip) = w_err_data{J_HO_in + j}(t,ip);
                w_err_data_vec_HO_oos{j}((ip-1)*T + t) = w_err_data_vec{J_HO_in + j}((ip-1)*T + t);
            end
        end
    end

    exa_DRO_master_matrix
    exa_DRO_sub_matrix

    uo_exa_DRO_HO = cell(N_ep,1);
    uu_exa_DRO_HO = cell(N_ep,1);
    ud_exa_DRO_HO = cell(N_ep,1);
    xu_exa_DRO_HO = cell(N_ep,1);
    xl_exa_DRO_HO = cell(N_ep,1);

    beta = 100/1;
    delta = max(1,beta/J_HO_in);

    bin_wind_err_basic_DRO_limited_HO = cell(T,N_ep);
    for t = 1 : T
        for i_ep = 1 : N_ep
            bin_wind_err_basic_DRO_limited_HO{t,i_ep} = bin_wind_err_basic{t};
        end
    end

    for i_ep = 1 : N_ep

        epsilon = epsilon_DRO_track(i_ep);
        for t = 1 : T
            for ip = 1 : np
                a = I_np(ip,:);
                dum = 0;
                for j = 1 : J_HO_in
                    dum = [ dum; a * w_err_data_HO_in{j}(t,:)' ];
                end
                dum(1) = [];
                dum_sort = sort(dum);
                % refine the support
                bin_wind_err_basic_DRO_limited_HO{t,i_ep}(ip) = min( bin_wind_err_basic_DRO_limited_HO{t,i_ep}(ip), dum_sort(end) + delta * J_HO_in * epsilon);
                bin_wind_err_basic_DRO_limited_HO{t,i_ep}(np + ip) = min( bin_wind_err_basic_DRO_limited_HO{t,i_ep}(np + ip), - dum_sort(1) + delta * J_HO_in * epsilon);
            end
        end

        K = 0;
        n = 3*ng*T + 2*ng*T + 1 + J_HO_in + ( ng*T + np*T + nl_shed*T );
        Ain = [
            C0 zeros(size(C0,1),n-3*ng*T);
            C11 C12 zeros(size(C11,1),n-5*ng*T);
            zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),1+J_HO_in) [C22 zeros(size(C22,1),np*T + nl_shed*T)] ;
            zeros(size(C61,1),5*ng*T+1+J_HO_in) [C61 C62 C63];
            ];
        bin = [ c0; c1; c2; c6 + C64 * zeros(np*T,1) ];
        Aeq = [ zeros(size(C81,1),5*ng*T + 1 + J_HO_in) C81 C82 C83 ];
        beq = c8 + C84 * zeros(np*T,1);
        f = [
            kron(Cu,ones(T,1));
            kron(Csu,ones(T,1));
            kron(Csd,ones(T,1));
            zeros(2*ng*T,1);
            epsilon;
            1/J_HO_in * ones(J_HO_in,1);
            zeros(n - 5*ng*T - 1 - J_HO_in,1)
            ];
        lb = zeros(n,1);
        ub = [ ones(3*ng*T,1); inf*ones(2*ng*T+1+J_HO_in,1); inf*ones(ng*T,1); zeros(np*T,1); d_shed_limit ];
        ctype = [ repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 1 + J_HO_in + ng*T + np*T + nl_shed*T) ];
        constraint_checker = 1;
        while constraint_checker > 0
            K = K + 1;
            sol = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
            uo_exa_DRO_HO{i_ep} = sol(1 : ng*T);
            uu_exa_DRO_HO{i_ep} = sol(ng*T + 1 : 2*ng*T);
            ud_exa_DRO_HO{i_ep} = sol(2*ng*T + 1 : 3*ng*T);
            xu_exa_DRO_HO{i_ep} = sol(3*ng*T + 1 : 4*ng*T);
            xl_exa_DRO_HO{i_ep} = sol(4*ng*T + 1 : 5*ng*T);
            lambda = sol(5*ng*T + 1);
            s = sol(5*ng*T + 1 + 1 : 5*ng*T + 1 + J_HO_in);
            constraint_checker = 0;
            exa_RO_feas_matrix
            xu = xu_exa_DRO_HO{i_ep};
            xl = xl_exa_DRO_HO{i_ep};
            exa_RO_feas_problem
            if imbalance < 1e-5
                for j = 1 : J_HO_in
                    exa_DRO_sub_problem_HO
                    dum_w_err_wc = w_err_plus_u_HO .* sigma_plus - w_err_minus_u_HO .*sigma_minus;
                    dum_norm = sum(w_err_plus_u_HO .* sigma_plus + w_err_minus_u_HO .*sigma_minus);
                    if s(j) > 0
                        dum_err = (UB-s(j))/s(j);
                    else
                        dum_err = UB-s(j);
                    end
                    if 1e-3 < dum_err
                        constraint_checker = constraint_checker + 1;
                        Ain = [
                            Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                            zeros(1,5*ng*T) -dum_norm -I_J_HO_in(j,:) zeros(1, size(Ain,2) - 5*ng*T - 1 - J_HO_in) kron(Cg',ones(1,T)) Cwc' Cds';
                            zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                            zeros(size(C61,1),size(Ain,2)) [C61 C62 C63];
                            ];
                        bin = [
                            bin;
                            0;
                            c2;
                            c6 + C64 * (w_forecast_vec + w_err_data_vec_HO_in{j} + dum_w_err_wc);
                            ];
                        Aeq = [
                            Aeq zeros(size(Aeq,1),ng*T+np*T+nl_shed*T);
                            zeros(size(C81,1),size(Aeq,2))  [C81 C82 C83]
                            ];
                        beq = [
                            beq;
                            c8 + C84 * (w_forecast_vec + w_err_data_vec_HO_in{j} + dum_w_err_wc)
                            ];
                        f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
                        lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
                        ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_data_vec_HO_in{j} + dum_w_err_wc; d_shed_limit] ];
                        ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
                        n = n + ng*T + np*T + nl_shed*T;
                    end
                end
            else
                constraint_checker = constraint_checker + 1;
                dum_w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
                Ain = [
                    Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                    zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                    zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                    ];
                bin = [
                    bin;
                    c2;
                    c6 + C64 * (w_forecast_vec + dum_w_err_wc) 
                    ];
                Aeq = [
                    Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                    zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                    ];
                beq = [
                    beq;
                    c8 + C84 * (w_forecast_vec + dum_w_err_wc)
                    ];
                f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
                lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
                ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + dum_w_err_wc; d_shed_limit] ];
                ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
                n = n + (ng*T + np*T + nl_shed*T);
            end
        end
    end

    %% HO: oos cost
    Ain_oos = [
        kron(Fg,I_T) -kron(Fp,I_T) kron(Fl_shed,I_T);
        -kron(Fg,I_T) kron(Fp,I_T) -kron(Fl_shed,I_T)
        ];
    for j = 1 : J_HO_oos
        bin_oos = [
            kron(Fmax,ones(T,1)) - kron(Fp,I_T)*(w_forecast_vec + w_err_data_vec_HO_oos{j}) + kron(Fl,I_T)*d;
            -kron(Fmin,ones(T,1)) + kron(Fp,I_T)*(w_forecast_vec + w_err_data_vec_HO_oos{j}) - kron(Fl,I_T)*d;
            ];
        Aeq_oos = kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T));
        beq_oos = d_sum - w_forecast_sum - sum(w_err_data_HO_oos{j},2);
        for i_ep = 1 : N_ep
            [~,dum] = cplexlp(Cg_ext,Ain_oos,bin_oos,Aeq_oos,beq_oos,[xl_aff_DRO_limited_HO{i_ep}; zeros(np*T+nl_shed*T,1)],[xu_aff_DRO_limited_HO{i_ep}; w_forecast_vec + w_err_data_vec_HO_oos{j}; d_shed_limit]);
            fval_oos_exa_DRO_HO(j,i_ep) = ...
                kron(Cu,ones(T,1))'*uo_exa_DRO_HO{i_ep} + ...
                kron(Csu,ones(T,1))'*uu_exa_DRO_HO{i_ep} + ...
                kron(Csd,ones(T,1))'*ud_exa_DRO_HO{i_ep} + dum;
        end
    end
    if J_HO_in == 1
        [~,dum] = sort(fval_oos_exa_DRO_HO);
        epsilon_exa_DRO = epsilon_DRO_track(dum(1));
    else
        [~,dum] = sort(sum(fval_oos_exa_DRO_HO));
        epsilon_exa_DRO = epsilon_DRO_track(dum(1));
    end

    %% exa DRO: actual
    exa_DRO_master_matrix
    exa_DRO_sub_matrix
    delta = max(1,beta/J);
    i_ep = [];
    bin_wind_err_basic_DRO_limited = cell(T,1);
    for t = 1 : T
        bin_wind_err_basic_DRO_limited{t,1} = bin_wind_err_basic{t};
    end
    epsilon = epsilon_exa_DRO_limited;
    for t = 1 : T
        for ip = 1 : np
            a = I_np(ip,:);
            dum = 0;
            for j = 1 : J
                dum = [ dum; a * w_err_data{j}(t,:)' ];
            end
            dum(1) = [];
            dum_sort = sort(dum);
            % refine the support
            bin_wind_err_basic_DRO_limited{t,1}(ip) = min( bin_wind_err_basic_DRO_limited{t,1}(ip), dum_sort(end) + delta * J * epsilon);
            bin_wind_err_basic_DRO_limited{t,1}(np + ip) = min( bin_wind_err_basic_DRO_limited{t,1}(np + ip), - dum_sort(1) + delta * J * epsilon);
        end
    end

    K = 0;
    n = 3*ng*T + 2*ng*T + 1 + J + ( ng*T + np*T + nl_shed*T );
    Ain = [
        C0 zeros(size(C0,1),n-3*ng*T);
        C11 C12 zeros(size(C11,1),n-5*ng*T);
        zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),1+J) [C22 zeros(size(C22,1),np*T + nl_shed*T)] ;
        zeros(size(C61,1),5*ng*T+1+J) [C61 C62 C63];
        ];
    bin = [ c0; c1; c2; c6 + C64 * zeros(np*T,1) ];
    Aeq = [ zeros(size(C81,1),5*ng*T + 1 + J) C81 C82 C83 ];
    beq = c8 + C84 * zeros(np*T,1);
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T,1);
        epsilon;
        1/J * ones(J,1);
        zeros(n - 5*ng*T - 1 - J,1)
        ];
    lb = zeros(n,1);
    ub = [ ones(3*ng*T,1); inf*ones(2*ng*T+1+J,1); inf*ones(ng*T,1); zeros(np*T,1); d_shed_limit ];
    ctype = [ repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 1 + J + ng*T + np*T + nl_shed*T) ];
    constraint_checker = 1;
    while constraint_checker > 0
        K = K + 1;
        [sol,est_exa_DRO] = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
        uo_exa_DRO = sol(1 : ng*T);
        uu_exa_DRO = sol(ng*T + 1 : 2*ng*T);
        ud_exa_DRO = sol(2*ng*T + 1 : 3*ng*T);
        xu_exa_DRO = sol(3*ng*T + 1 : 4*ng*T);
        xl_exa_DRO = sol(4*ng*T + 1 : 5*ng*T);
        lambda = sol(5*ng*T + 1);
        s = sol(5*ng*T + 1 + 1 : 5*ng*T + 1 + J);
        constraint_checker = 0;
        exa_RO_feas_matrix
        xu = xu_exa_DRO;
        xl = xl_exa_DRO;
        exa_RO_feas_problem
        if imbalance < 1e-5
            for j = 1 : J
                exa_DRO_sub_problem
                dum_w_err_wc = w_err_plus_u .* sigma_plus - w_err_minus_u .*sigma_minus;
                dum_norm = sum(w_err_plus_u .* sigma_plus + w_err_minus_u .*sigma_minus);
                if s(j) > 0
                    dum_err = (UB-s(j))/s(j);
                else
                    dum_err = UB-s(j);
                end
                if 1e-3 < dum_err
                    constraint_checker = constraint_checker + 1;
                    Ain = [
                        Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                        zeros(1,5*ng*T) -dum_norm -I_J(j,:) zeros(1, size(Ain,2) - 5*ng*T - 1 - J) kron(Cg',ones(1,T)) Cwc' Cds';
                        zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                        zeros(size(C61,1),size(Ain,2)) [C61 C62 C63];
                        ];
                    bin = [
                        bin;
                        0;
                        c2;
                        c6 + C64 * (w_forecast_vec + w_err_data_vec{j} + dum_w_err_wc);
                        ];
                    Aeq = [
                        Aeq zeros(size(Aeq,1),ng*T+np*T+nl_shed*T);
                        zeros(size(C81,1),size(Aeq,2))  [C81 C82 C83]
                        ];
                    beq = [
                        beq;
                        c8 + C84 * (w_forecast_vec + w_err_data_vec{j} + dum_w_err_wc)
                        ];
                    f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
                    lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
                    ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_data_vec{j} + dum_w_err_wc; d_shed_limit] ];
                    ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
                    n = n + ng*T + np*T + nl_shed*T;
                end
            end
        else
            constraint_checker = constraint_checker + 1;
            dum_w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
                ];
            bin = [
                bin;
                c2;
                c6 + C64 * (w_forecast_vec + dum_w_err_wc) 
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
                zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + dum_w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + dum_w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
            n = n + (ng*T + np*T + nl_shed*T);
        end
    end

    time_exa_DRO = toc;
    
    fname = sprintf('sol_EWDR_%d.mat', is);
    save(fname)

end
