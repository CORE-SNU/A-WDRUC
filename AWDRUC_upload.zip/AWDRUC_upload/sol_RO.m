clear

load('6bus.mat')
%load('24bus.mat')

nl_shed = min(nl,10);
d_reshape = reshape(d,T,nl);
[~,d_shed_index] = sort(sum(d_reshape),'descend');
Il_shed = d_shed_index(1 : nl_shed);
I_nl_shed = eye(nl_shed);
d_shed_limit = zeros(nl_shed*T,1);
for i_dum = 1 : nl_shed
    il = Il_shed(i_dum);
    d_shed_limit((i_dum-1)*T+1:i_dum*T) = 1 * d((il-1)*T+1:il*T);
end
Fl_shed = Fl(:,Il_shed);

forecast_day = 183; 

w_forecast = zeros(T,np);
for ip = 1 : np
    w_forecast(:,ip) = cap(ip) * PV_pred_Year{ip,forecast_day};
end
w_forecast_sum = sum(w_forecast,2);
w_forecast_vec = reshape(w_forecast,[],1);
Ain_wind_err_basic = [ eye(np); -eye(np) ];
bin_wind_err_basic = cell(T,1);
for t = 1 : T
    bin_wind_err_basic{t} = [ cap - w_forecast(t,:)'; w_forecast(t,:)' ];
end

w_err_u_vec = kron(cap,ones(T,1)) - w_forecast_vec;
w_err_l_vec = - w_forecast_vec;

I_T = eye(T); I_ng = eye(ng); I_nl = eye(nl);
I_np = eye(np); I_npT = eye(np*T); 
d_res = reshape(d,T,nl)';
d_sum = sum(d_res)';

Cwc = zeros(np*T,1);
Cds = 100 * max(Cg) * ones(nl_shed*T,1);
Cg_ext = [ kron(Cg,ones(T,1)); Cwc; Cds ];

%% RO
tic

common_matrix
exa_DRO_master_matrix
exa_RO_feas_matrix
exa_RO_sub_matrix
K = 0;
n_RO = 3*ng*T + 2*ng*T + 1 + ( ng*T + np*T + nl_shed*T );
Ain = [
    C0 zeros(size(C0,1),n_RO - 3*ng*T);
    C11 C12 zeros(size(C11,1),n_RO - 5*ng*T);
    zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),1) [ C22 zeros(size(C22,1),np*T + nl_shed*T) ] ;
    zeros(size(C61,1),5*ng*T+1) [ C61 C62 C63 ];
    zeros(1,3*ng*T + 2*ng*T) -1 kron(Cg',ones(1,T)) Cwc' Cds';
    ];
bin = [ c0; c1; c2; c6 + C64 * zeros(np*T,1); zeros(1,1) ];
Aeq = [ zeros(size(C81,1),5*ng*T + 1) C81 C82 C83 ];
beq = c8 + C84 * zeros(np*T,1);
f = [
    kron(Cu,ones(T,1));
    kron(Csu,ones(T,1));
    kron(Csd,ones(T,1));
    zeros(2*ng*T,1);
    1;
    zeros(n_RO - 5*ng*T - 1,1)
    ];
lb = zeros(n_RO,1);
ub = [ ones(3*ng*T,1); inf*ones(2*ng*T+1,1); inf*ones(ng*T,1); zeros(np*T,1); d_shed_limit ];
ctype = [ repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + 1 + ng*T + np*T + nl_shed*T) ];

err_RO = 1;
while err_RO > 5e-3
    K = K + 1;
    [sol,est_exa_RO] = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
    uo_exa_RO = sol(1 : ng*T);
    uu_exa_RO = sol(ng*T + 1 : 2*ng*T);
    ud_exa_RO = sol(2*ng*T + 1 : 3*ng*T);
    xu_exa_RO = sol(3*ng*T + 1 : 4*ng*T);
    xl_exa_RO = sol(4*ng*T + 1 : 5*ng*T);
    cost_ED_RO = sol(5*ng*T + 1);
    UCcost_RO = est_exa_RO - cost_ED_RO;
    xu = xu_exa_RO;
    xl = xl_exa_RO;
    exa_RO_feas_problem
    if imbalance < 1e-5
        exa_RO_sub_problem
        w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma ;
        err_RO = (UB + UCcost_RO - est_exa_RO)/est_exa_RO;
        if err_RO > 5e-3
            Ain = [
                Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
                zeros(1,5*ng*T) -1 zeros(1, size(Ain,2) - 5*ng*T - 1) kron(Cg',ones(1,T)) Cwc' Cds';
                zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
                zeros(size(C61,1),size(Ain,2)) [C61 C62 C63];
                ];
            bin = [
                bin;
                0;
                c2;
                c6 + C64 * (w_forecast_vec + w_err_wc);
                ];
            Aeq = [
                Aeq zeros(size(Aeq,1),ng*T+np*T+nl_shed*T);
                zeros(size(C81,1),size(Aeq,2))  [C81 C82 C83]
                ];
            beq = [
                beq;
                c8 + C84 * (w_forecast_vec + w_err_wc)
                ];
            f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
            lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
            ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
            ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];
            n_RO = n_RO + ng*T + np*T + nl_shed*T;
        end
    else
        w_err_wc = w_err_l_vec + (w_err_u_vec - w_err_l_vec) .* sigma;
        Ain = [
            Ain zeros(size(Ain,1),ng*T + np*T + nl_shed*T);
            zeros(size(C21,1),3*ng*T) C21 zeros(size(C21,1),size(Ain,2)-5*ng*T) C22 zeros(size(C22,1),np*T + nl_shed*T);
            zeros(size(C61,1),size(Ain,2)) C61 C62 C63;
            ];
        bin = [
            bin;
            c2;
            c6 + C64 * (w_forecast_vec + w_err_wc)
            ];
        Aeq = [
            Aeq zeros(size(Aeq,1),ng*T + np*T + nl_shed*T);
            zeros(size(C81,1),size(Aeq,2)) C81 C82 C83
            ];
        beq = [
            beq;
            c8 + C84 * (w_forecast_vec + w_err_wc)
            ];
        f = [ f; zeros(ng*T + np*T + nl_shed*T,1) ];
        lb = [ lb; zeros(ng*T + np*T + nl_shed*T,1) ];
        ub = [ ub; [inf*ones(ng*T,1); w_forecast_vec + w_err_wc; d_shed_limit] ];
        ctype = [ ctype repmat('C',1,ng*T + np*T + nl_shed*T) ];   
        n_RO = n_RO + (ng*T + np*T + nl_shed*T);
    end
end
time_exa_RO = toc;

save('sol_RO.mat');
