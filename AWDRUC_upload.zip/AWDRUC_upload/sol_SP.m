clear

for is = 1 : 50
    
    fname = sprintf('sol_AWDR_%d.mat', is);
    load(fname)

    tic

    common_matrix
    n_exa_SP = 3*ng*T + 2*ng*T + J*(ng*T + np*T + nl_shed*T);
    Ain = [
        C0 zeros(size(C0,1),n_exa_SP - 3*ng*T);
        C11 C12 zeros(size(C11,1),n_exa_SP - 5*ng*T);
        zeros(ng*J*T,3*ng*T) -kron(ones(J,1),eye(ng*T)) zeros(ng*T*J,ng*T) kron(eye(J),kron([eye(ng) zeros(ng,np + nl_shed)],eye(T)));
        zeros(ng*J*T,3*ng*T+ng*T) kron(ones(J,1),eye(ng*T)) -kron(eye(J),kron([eye(ng) zeros(ng,np + nl_shed)],eye(T)));
        zeros(J*M*T,5*ng*T) kron(eye(J),kron([Fg -Fp Fl_shed],I_T))
        zeros(J*M*T,5*ng*T) kron(eye(J),kron([-Fg Fp -Fl_shed],I_T))
        ];
    bin = [
        a0;
        c1;
        zeros(2*ng*J*T,1);
        kron(ones(J,1),kron(Fmax,ones(T,1)) - kron(Fp,I_T)*w_forecast_vec + kron(Fl,I_T)*d) - kron(eye(J),kron(Fp,I_T))*w_err_data_vec_stack_all;
        kron(ones(J,1),-kron(Fmin,ones(T,1)) + kron(Fp,I_T)*w_forecast_vec - kron(Fl,I_T)*d) + kron(eye(J),kron(Fp,I_T))*w_err_data_vec_stack_all;
        ];
    Aeq = [
        zeros(J*T,5*ng*T) kron(eye(J),kron([ones(1,ng) -ones(1,np) ones(1,nl_shed)],eye(T)));
        ];
    beq = [
        kron(ones(J,1),d_sum - w_forecast_sum) - kron(eye(J),kron(ones(1,np),I_T)) * w_err_data_vec_stack_all;
        ];
    lb = [
        zeros(3*ng*T,1); zeros(2*ng*T,1); zeros(J*(ng*T+np*T+nl_shed*T),1)
        ];
    ub = [
        ones(3*ng*T,1); inf*ones(2*ng*T,1); kron(ones(J,1),[inf*ones(ng*T,1); inf*ones(np*T,1); d_shed_limit])
        ];
    for j = 1 : J
        ub( 5*ng*T+ (j-1)*(ng*T + np*T + nl_shed*T) + ng*T + 1 : + 5*ng*T+ (j-1)*(ng*T + np*T + nl_shed*T) + ng*T + np*T ) = w_forecast_vec + w_err_data_vec{j};
    end
    ctype = [
        repmat('B',1,3*ng*T) repmat('C',1,2*ng*T + J*(ng*T+np*T+nl_shed*T))
        ];
    f = [
        kron(Cu,ones(T,1));
        kron(Csu,ones(T,1));
        kron(Csd,ones(T,1));
        zeros(2*ng*T,1);
        1/J * kron(ones(J,1),Cg_ext)
        ];
    [sol,WCEXP] = cplexmilp(f,Ain,bin,Aeq,beq,[],[],[],lb,ub,ctype);
    time_exa_SP = toc;
    uo_exa_SP = sol(1 : ng*T);
    uu_exa_SP = sol(ng*T+1 : 2*ng*T);
    ud_exa_SP = sol(2*ng*T + 1 : 3*ng*T);
    xu_exa_SP = sol(3*ng*T + 1 : 4*ng*T);
    xl_exa_SP = sol(4*ng*T + 1 : 5*ng*T);
    est_exa_SP = WCEXP;

    fname = sprintf('sol_SP_%d.mat',is);
    save(fname)

end
